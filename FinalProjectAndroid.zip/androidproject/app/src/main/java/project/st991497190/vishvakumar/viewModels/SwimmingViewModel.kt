package project.st991497190.vishvakumar.viewModels

import androidx.lifecycle.ViewModel

class SwimmingViewModel : ViewModel() {
}